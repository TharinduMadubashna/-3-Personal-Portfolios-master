function openMenu() {
    const nav = document.querySelector('nav');
    nav.classList.toggle('open');
}